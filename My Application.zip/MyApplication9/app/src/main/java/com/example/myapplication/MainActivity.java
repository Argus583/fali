package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    Button btn;
    EditText last, name, ot, age;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        last = findViewById(R.id.last);
        name = findViewById(R.id.name);
        ot = findViewById(R.id.ot);
        age = findViewById(R.id.age);

        // Измените код обработчика нажатия кнопки следующим образом
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String surname = last.getText().toString();
                String personName = name.getText().toString(); // переименовываем переменную, чтобы избежать конфликта с полем класса
                String patronymic = ot.getText().toString();
                String personAge = age.getText().toString(); // переименовываем переменную, чтобы избежать конфликта с полем класса

                Intent intent = new Intent(MainActivity.this, Activity_second.class); // исправление ошибки

                intent.putExtra("surname", surname);
                intent.putExtra("name", personName); // используем переименованную переменную
                intent.putExtra("patronymic", patronymic);
                intent.putExtra("age", personAge); // используем переименованную переменную

                startActivity(intent);
            }
        });
    }
}
