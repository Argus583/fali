package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Activity_second extends AppCompatActivity {
    TextView slast, sname, sot, sage;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        slast = findViewById(R.id.last);
        sname = findViewById(R.id.name);
        sot = findViewById(R.id.ot);
        sage = findViewById(R.id.age);
        btn = findViewById(R.id.btn);

        // Получение данных из Intent, отправленного из MainActivity
        Intent intent = getIntent();
        String surname = intent.getStringExtra("surname");
        String name = intent.getStringExtra("name");
        String patronymic = intent.getStringExtra("patronymic");
        String age = intent.getStringExtra("age");

        // Отображение данных в TextView в Activity_second
        slast.setText(surname);
        sname.setText(name);
        sot.setText(patronymic);
        sage.setText(age);

        // Устанавливаем обработчик нажатия на кнопку "Назад"
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Создаем новый Intent для возврата в MainActivity
                Intent intent = new Intent(Activity_second.this, MainActivity.class);
                // Запускаем MainActivity
                startActivity(intent);
            }
        });
    }
}
